// tslint:disable-next-line:class-name
export class Contact {
    constructor(

        public fullname: string,
        public email: string,
        public contact: number,
        public message: string


    ) { }
}
