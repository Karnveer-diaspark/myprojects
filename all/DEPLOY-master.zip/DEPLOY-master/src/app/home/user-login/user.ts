// tslint:disable-next-line:class-name
export class UserLogin {
    constructor(
        public seviceUsername: string,
        public  sevicePassword: string,

    ) { }
}
