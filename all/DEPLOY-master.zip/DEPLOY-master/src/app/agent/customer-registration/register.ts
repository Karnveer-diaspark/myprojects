// tslint:disable-next-line:class-name
export class register {
    constructor(
        public title: string,
        public firstname: string,
        public lastname: string,
        public email: string,
        public phone: number,
        public address: string,
        public adhar: number,
        public policy: string,
        public nominie: string,
        public relation: string



    ) { }
}
