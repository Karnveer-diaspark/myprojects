// const nodemailer = require('nodemailer');

// var transporter = nodemailer.createTransport({
//     service: 'mailtrap',
//     auth: {
//         user: 'd575ad8ce69a48',
//         pass: '087e2a3bccdd1e'
//     }
// });

// module.exports= nodemailer;