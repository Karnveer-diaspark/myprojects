# node-jwt
Accompanying repository for scotch article on auth with JWTs and node
